<?php
include "connection.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>admin functions page</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/astyle.css">

</head>
<body style="background-image:url('pexels-gdtography-911738.jpg');background-position: center;
  background-repeat: no-repeat;
  background-size: cover;">
  <div class="container">
  <div class="content">
    <br><br>
    <h1>Welcome <span>
      Admin
      </span></h1>
  <h2>This is an admin functions page</h2><br>
      
      <a href="Classic_Adding.php" class="btn" style="width:400px">Classic Page Control</a><br><br>
      <a href="Modern_Adding.php" class="btn"style="width:400px">Modern Page Control</a><br><br>
      <a href="Indoor_Adding.php" class="btn"style="width:400px">Indoor Page Control</a><br><br>
      <a href="New_Arr_Adding.php" class="btn"style="width:400px">New arrivals Part Control</a><br><br>
      <a href="Addresses_Adding.php" class="btn"style="width:400px">Addresses Page Control</a><br><br>
      <a href="#" class="btn"style="width:400px"> Category Image Control</a><br><br>
      <a href="#" class="btn"style="width:400px"> Users Orders</a><br><br>
      <a href="#" class="btn"style="width:400px"> Users Messages & complaines</a><br><br>
      <a href="../index.php" class="btn"style="width:400px"> Preview Website</a><br><br>
      <a href="admin_page.php" class="btn"style="width:400px">Back To Admin Main Page</a><br><br>
</div>
</div>
</body> 